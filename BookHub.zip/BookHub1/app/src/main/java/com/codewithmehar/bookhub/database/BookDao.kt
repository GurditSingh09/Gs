package com.codewithmehar.bookhub.database

import androidx.room.*
import androidx.viewpager.widget.ViewPager

@Dao
interface BookDao {

    @Insert
    fun insertBook(bookEntity: BookEntities)

    @Delete
    fun deleteBook(bookEntity: BookEntities)

    @Query("SELECT * FROM books")
    fun getAllBooks(): List<BookEntities>

    @Query("SELECT * FROM books WHERE book_id = :bookId")
    fun getBookById(bookId: String) : BookEntities


}